# ESP32 ASR Capture Vision MVP - Backend Package
__version__ = "0.1.0"
