# OneDrive 備份指南

## 📦 需要上傳的檔案

### 方式 A：使用打包腳本（推薦）

```bash
# 執行打包腳本
chmod +x package_for_backup.sh
./package_for_backup.sh

# 會產生兩個檔案：
# - esp32-asr-mvp-backup-YYYYMMDD_HHMMSS.tar.gz (Linux/Mac)
# - esp32-asr-mvp-backup-YYYYMMDD_HHMMSS.zip (Windows)

# 上傳其中一個到 OneDrive
```

### 方式 B：手動選擇檔案

#### 必須上傳的檔案（核心程式碼）

**後端（backend/）**：
```
backend/
├── __init__.py
├── main.py                    # ⭐ 主程式
├── models.py                  # ⭐ 資料模型
├── config.py                  # ⭐ 配置管理
├── event_bus.py              # ⭐ 事件匯流排
├── asr_bridge.py             # ⭐ ASR 橋接
├── trigger_engine.py         # ⭐ 觸發引擎
├── capture_coordinator.py    # ⭐ 拍照協調
├── vision_adapter.py         # ⭐ 視覺模型
├── app_coordinator.py        # ⭐ 應用協調
├── requirements.txt          # ⭐ 依賴清單
└── .env.example              # ⭐ 環境變數範本
```

**前端（web/）**：
```
web/
├── index.html                # ⭐ 主頁面
├── style.css                 # ⭐ 樣式
└── app.js                    # ⭐ 前端邏輯
```

**ESP32 韌體（device/）**：
```
device/
├── esp32_full_firmware.ino   # ⭐ 完整韌體
├── esp32_camera_test.ino     # ⭐ 測試版本
└── esp32_simulator.py        # ⭐ Python 模擬器
```

**測試（tests/）**：
```
tests/
├── __init__.py
├── conftest.py               # ⭐ Pytest 配置
└── test_models.py            # ⭐ 模型測試
```

**文件（根目錄）**：
```
├── README.md                 # ⭐ 專案說明
├── QUICKSTART.md            # ⭐ 快速開始
├── DEPLOYMENT.md            # ⭐ 部署指南
├── TESTING.md               # ⭐ 測試指南
├── API.md                   # ⭐ API 文件
├── PROJECT_SUMMARY.md       # ⭐ 專案總結
├── BACKUP_GUIDE.md          # ⭐ 備份指南（本文件）
├── test_upload.py           # ⭐ 測試腳本
├── start_server.sh          # ⭐ 啟動腳本
├── package_for_backup.sh    # ⭐ 打包腳本
├── pytest.ini               # ⭐ Pytest 配置
└── .gitignore               # ⭐ Git 忽略規則
```

**規格文件（.kiro/specs/）**：
```
.kiro/specs/esp32-asr-capture-vision-mvp/
├── requirements.md           # ⭐ 需求文件
├── design.md                # ⭐ 設計文件
└── tasks.md                 # ⭐ 任務清單
```

---

## 📤 上傳步驟

### 在 AWS EC2 上

#### 1. 打包檔案

```bash
# 方式 A：使用腳本
./package_for_backup.sh

# 方式 B：手動打包
tar -czf esp32-asr-mvp.tar.gz \
  backend/ \
  web/ \
  device/ \
  tests/ \
  .kiro/ \
  *.md \
  *.py \
  *.sh \
  *.ini \
  .gitignore
```

#### 2. 下載到本機

```bash
# 在本機執行（不是在 EC2 上）
scp -i your-key.pem ec2-user@your-ec2-ip:~/esp32-asr-mvp-backup-*.tar.gz ~/Downloads/
```

#### 3. 上傳到 OneDrive

- 開啟 OneDrive 網頁版或桌面應用程式
- 建立資料夾：`ESP32-ASR-Vision-MVP`
- 上傳壓縮檔

---

## 💾 不需要上傳的檔案

以下檔案可以重新生成，不需要備份：

❌ **不要上傳**：
- `venv/` - 虛擬環境（可重建）
- `__pycache__/` - Python 快取
- `*.pyc` - 編譯的 Python 檔案
- `.pytest_cache/` - Pytest 快取
- `.hypothesis/` - Hypothesis 快取
- `images/` - 儲存的影像（測試資料）
- `*.log` - 日誌檔案
- `.env` - 環境變數（包含 API 金鑰，不要上傳！）
- `node_modules/` - Node.js 依賴（如果有）

---

## 📥 從 OneDrive 恢復

### 1. 下載備份

從 OneDrive 下載壓縮檔到本機

### 2. 解壓縮

```bash
# Linux/Mac
tar -xzf esp32-asr-mvp-backup-*.tar.gz

# Windows
# 右鍵 → 解壓縮
```

### 3. 部署到新的 EC2

```bash
# 上傳到 EC2
scp -i your-key.pem -r esp32-asr-mvp-backup-*/ ec2-user@new-ec2-ip:~/

# SSH 到 EC2
ssh -i your-key.pem ec2-user@new-ec2-ip

# 進入目錄
cd esp32-asr-mvp-backup-*/

# 啟動服務
./start_server.sh
```

---

## 🔐 安全提醒

### ⚠️ 重要：不要上傳敏感資訊

**絕對不要上傳**：
- ❌ `backend/.env` - 包含 API 金鑰
- ❌ AWS 金鑰檔案（.pem）
- ❌ 任何包含密碼的檔案

**安全做法**：
- ✅ 只上傳 `.env.example`（範本）
- ✅ API 金鑰另外安全儲存（密碼管理器）
- ✅ 使用 `.gitignore` 防止意外上傳

---

## 📋 備份檢查清單

上傳前確認：

- [ ] 已打包所有原始碼
- [ ] 已包含所有文件（.md 檔案）
- [ ] 已包含配置範本（.env.example）
- [ ] 已包含測試檔案
- [ ] 已包含 ESP32 韌體
- [ ] **沒有**包含 .env（API 金鑰）
- [ ] **沒有**包含 venv/
- [ ] **沒有**包含 images/
- [ ] 壓縮檔大小合理（< 10MB）

---

## 🔄 快速恢復流程

```bash
# 1. 從 OneDrive 下載
# 2. 解壓縮
tar -xzf esp32-asr-mvp-backup-*.tar.gz

# 3. 進入目錄
cd esp32-asr-mvp-backup-*/

# 4. 設定環境變數
cp backend/.env.example backend/.env
nano backend/.env  # 填入 API 金鑰

# 5. 啟動服務
./start_server.sh
```

---

## 📊 預期檔案大小

- **原始碼**：~500 KB
- **文件**：~200 KB
- **壓縮後**：~100-200 KB

如果壓縮檔 > 10MB，可能包含了不必要的檔案（venv、images 等）

---

## 💡 建議

1. **定期備份**：每次重大更新後備份
2. **版本命名**：使用時間戳記（已自動處理）
3. **多重備份**：OneDrive + GitHub + 本機
4. **測試恢復**：定期測試能否成功恢復
5. **文件同步**：確保文件與程式碼同步

---

## 🎯 最小備份（緊急用）

如果時間緊迫，至少備份這些：

```bash
# 最小備份（~50KB）
tar -czf minimal-backup.tar.gz \
  backend/*.py \
  backend/requirements.txt \
  web/*.html web/*.css web/*.js \
  device/*.ino \
  README.md \
  QUICKSTART.md
```

這樣至少保留了核心程式碼和基本文件。
